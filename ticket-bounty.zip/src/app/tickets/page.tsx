import { initialTickets } from "@/data";
import Link from "next/link";
const TICKET_ICONS = {
  OPEN: "O",
  IN_PROGRESS: ">",
  DONE: "X",
};
export default function TicketPage() {
  return (
    <div className="flex flex-col flex-1 gap-y-8">
      <div>
        <h2 className="text-3xl font-bold tracking-tight">TicketsPage</h2>
        <p className="text-sm text-muted-foreground">
          All Your tickets at one place
        </p>
      </div>
      <div className="flex flex-col flex-1 items-center gap-y-4 animate-fade-in-from-top">
        {initialTickets.map((ticket) => (
          <div
            key={ticket.id}
            className="w-full max-w-[420px] p-4 border border-slate-100 rounded"
          >
            <div>{TICKET_ICONS[ticket.status]}</div>
            <h3 className="text-lg font-semibold truncate">{ticket.title}</h3>
            <p className="text-sm text-slate-500   truncate">
              {ticket.content}
            </p>
            <Link href={`/tickets/${ticket.id}`} className="underline">
              view
            </Link>
          </div>
        ))}
      </div>
    </div>
  );
}
